#### Your system information

* System information from steam (`Steam` -> `Help` -> `System Information`) in a [gist](https://gist.github.com/):
<!-- If on Linux, please include Steam -> Help -> Steam Runtime Diagnostics in the gist. -->
* Have you checked for system updates?: [Yes/No]

#### Please describe your issue in as much detail as possible:
Describe what you _expected_ should happen and what _did_ happen. Please link any large pastes as a [Github Gist](https://gist.github.com/).

#### Steps for reproducing this issue:

1. 
2. 
3. 
