<h1 align="center">ACPocketCampRestarter</h1>
<div align=center>
<a align="center" href="https://opensource.org/licenses/MIT" target="_blank">
    <img align="center" src="https://img.shields.io/badge/License-MIT-blue.svg" alt="License">
  </a>
  </div>
  <br>
<p align="center">
Android app for <b>rooted devices only</b>
</p>
<p align="center">
This app kills <i>deviceAccount:.xml</i> for SafetyCheck and Reboot Pocket Camp to play on rooted devices, 
</p>

